module.exports = {
  apps: [
    {
      name: 'fraga-dashboard',
      script: './dist/index.js',
      instances: 1,
      exec_mode: 'fork',
      watch: false,
      
      // Auto-restart configuration
      autorestart: true,
      max_memory_restart: '500M',
      
      // Environment
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      
      // Error handling
      error_file: '/var/log/fraga-dashboard/error.log',
      out_file: '/var/log/fraga-dashboard/out.log',
      log_file: '/var/log/fraga-dashboard/combined.log',
      time: true,
      
      // Graceful shutdown
      kill_timeout: 5000,
      shutdown_with_message: true,
      
      // Recovery strategy
      listen_timeout: 10000,
      
      // Monitoring
      monitor: {
        memory: 500,
        cpu: 80
      }
    },
    
    // Monitor de auto-recuperação (segundo plano)
    {
      name: 'fraga-monitor',
      script: './monitor-auto-recovery.sh',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      env: {
        NODE_ENV: 'production'
      },
      error_file: '/var/log/fraga-dashboard/monitor-error.log',
      out_file: '/var/log/fraga-dashboard/monitor-out.log'
    }
  ],
  
  // Global configuration
  deploy: {
    production: {
      user: 'fraga',
      host: 'localhost',
      ref: 'origin/main',
      repo: 'git@github.com:fraga/dashboard.git',
      path: '/opt/fraga-dashboard',
      'post-deploy': 'npm install --legacy-peer-deps && npm run build && pm2 restart ecosystem.config.js --env production'
    }
  }
};
